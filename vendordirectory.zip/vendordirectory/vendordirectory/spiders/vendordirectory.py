from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import VendordirectoryItem

#from datetime import date


class VendorDirectorySpider(CrawlSpider):

    name = "vendordirectory"

    img_link = "https://www.tatsoul.com/supplies/"

    start_urls = [
                "https://vendordirectory.shrm.org/"
    ]

    rules = (
        Rule(LinkExtractor(restrict_css=([".list-unstyled li a",".list-large .list-unstyled li a",".pagination li:last-child a"]))),
        Rule(LinkExtractor(restrict_css=(".media.listing .media-heading a")),callback="vendordirectory"),  
    )


    def vendordirectory(self, response):

        products = VendordirectoryItem()

        products["title"] = response.css(".media-body h1::text").extract_first()
        products["description"] = response.css(".profile-featured-ratings+ div::text").extract_first()

        products["rating"] = response.css("span[itemprop='ratingValue']::text").extract_first()

        if not products["rating"]:
            products["rating"] = 0

        products["phone"] = response.css("span[itemprop='telephone']::text").extract_first()

        products["website"] = response.css("a[itemprop='url']::attr(href)").extract_first()

        products["address"] = response.css("div[itemprop='streetAddress']::text").extract_first()

        products["city"] = response.css("div[itemprop='address'] div:nth-child(2) span:first-child::text").extract_first()

        products["addressRegion"] = response.css("span[itemprop='addressRegion']::text").extract_first()

        products["postalCode"] = response.css("span[itemprop='postalCode']::text").extract_first()

        products["url"] = response.url

        products["aboutMe"] = response.css(".list-group-item span[itemprop='description']:first-child::text").extract()

        if not products["aboutMe"]:
            products["aboutMe"] = response.css("li[itemprop='description']::text").extract()
        

        products["mediaSocial"] = response.css(".media-social a::attr(href)").extract()

        products["listedunder"] = response.css(".list-unstyled-wide.list-unstyled li a::text").extract()

        

        yield products
 